

TIME_FEATURE_STRATEGY_LIST = ['hour', 'day_of_week']
