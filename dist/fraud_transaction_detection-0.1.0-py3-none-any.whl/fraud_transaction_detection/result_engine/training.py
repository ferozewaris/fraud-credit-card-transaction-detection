from fraud_transaction_detection.result_engine.base import ResultManager


class TrainingResultManager(ResultManager):

    def __int__(self):
        pass

    # TODO Implementation of training results processing
    def _process_result(self, *args):
        print("results are processed")
